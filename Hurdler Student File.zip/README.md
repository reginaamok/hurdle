Starter code for the Hurdler Assignment
